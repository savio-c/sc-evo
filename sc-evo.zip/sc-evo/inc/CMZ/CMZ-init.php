<?php

require_once('CMZ__site-info.php');
require_once('CMZ__footer.php');
require_once('CMZ__function.php');
 ?>
